import React from "react";

const Message =()=>{

    let style={

        padding:"iron",
        marginBottom:"1rem",
        textAling:"center",
        color:"#fff"
    }
    return (
        <div>
            <h2>Message</h2>
        </div>
    );
}

export default Message;