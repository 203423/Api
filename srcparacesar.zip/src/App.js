import logo from './logo.svg';
import './App.css';
import CruddApp from './componentes/CrudApp';
import Crudform from './componentes/Crudform';
import CrudApi from './componentes/CrudApi';

function App() {
  return (
    <div>
      <CrudApi/>
     
      <table></table>
    </div>
  );
}

export default App;
